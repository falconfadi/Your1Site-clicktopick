<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
     <img onerror="this.src='{{asset('web/images/no-image.jpg')}}';"  alt="{{ config('app.title') }}" width="128" height="auto" src="{{ asset('custom/logo-icon.png') }}"/>
</svg>
