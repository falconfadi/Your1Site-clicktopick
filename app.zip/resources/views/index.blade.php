<x-app-front-layout>
    <x-slot name="title">Home</x-slot>


    @include('front-layouts.sections.slider')
    @include('front-layouts.sections.latest-collection')
    @include('front-layouts.sections.new-arrivals')
</x-app-front-layout>
