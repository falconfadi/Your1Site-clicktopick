<div id="kt_scrolltop" class="scrolltop">
    <span class="svg-icon">
        {{ getSVG('assets/media/svg/icons/Navigation/Up-2.svg') }}
    </span>
</div>
