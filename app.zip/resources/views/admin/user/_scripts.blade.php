<script src="{{ asset('custom/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('js/users.js') }}"></script>
