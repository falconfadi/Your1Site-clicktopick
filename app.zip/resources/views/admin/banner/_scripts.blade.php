<script src="{{ asset('custom/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('js/banners.js') }}"></script>
