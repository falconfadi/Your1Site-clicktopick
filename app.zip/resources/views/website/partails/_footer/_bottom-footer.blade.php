<div class="mx-auto">
    <p class="copyright">{{__('front.copyright')}}</p>
</div>