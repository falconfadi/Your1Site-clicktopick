<?php
return [
    'coupon_created_successfully' => 'Coupon Created successfully',
    'coupon_updated_successfully' => 'Coupon Updated',
    'coupon_deleted_successfully' => 'Coupon Deleted',
    'sort_order' => 'Order',
    'code' => 'Code',
    'name' => 'Name',
    'coupon_value' => 'Coupon Value',
    'start_date' => 'Start at',
    'end_date' => 'End at',
    'min_amount' => 'Minimum',
    'max_amount' => 'Maximum',
];
