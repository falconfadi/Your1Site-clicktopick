<?php

return [
    'slider_updated_successfully' => 'Slider updated successfully',
    'slider_deleted_successfully' => 'Slider deleted successfully',
    'slider_created_successfully' => 'Slider created successfully',
    'sort_order' => 'Sort order',
    'heading' => 'Heading',
    'title' => 'Title',
    'brief' => 'Brief',
    'main_heading' => 'Main heading',
    'offer_percentage' => 'Offer percentage',
    'offer_vertical' => 'Offer Vertical',
    'offer_duration' => 'Offer duration',
    'background_image' => 'Back ground image',
    'responsive_image' => 'Responsive image',
    'product_id' => 'Product id',
];
