<?php

return [
    'settings' => 'Settings',
    'key' => 'Key',
    'type' => 'Type',
    'select_type' => 'Select Type',
    'text' => 'Text',
    'textarea' => 'Long Text',
    'text_area' => 'Long Text',
    'text_editor' => 'Text Editor',
    'rich_text_box' => 'Text Editor',
    'number' => 'Number',
    'image' => 'Image',
    'album' => 'Album',
    'checkbox' => 'Checkbox',
    'select' => 'Select',
];
