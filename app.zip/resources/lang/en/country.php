<?php

return [
    'country_created_successfully' => 'Country created successfully',
    'country_deleted_successfully' => 'Country deleted successfully',
    'country_updated_successfully' => 'Country updated successfully',
    'delivery_rates' => 'Delivery rates',
    'country_details' => 'Country details',
    'show_cities' => 'Show Cities',
    'show_branches' => 'Show Branches',
    'name' => 'Name',
    'sort_order' => 'Sort order',
    'status' => 'status',
    'add_delivery_rates' => 'add delivery rates',
    'from_weight' => 'From weight',
    'to_weight' => 'To weight',
    'delivery_fee' => 'Delivery fee',
    'rates_count' => 'Rates count',
    'add' => 'Add',
    'remove' => 'Remove'

];
