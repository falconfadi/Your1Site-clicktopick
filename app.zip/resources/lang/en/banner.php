<?php

return [
    'banner_created_successfully' => 'Banner created successfully',
    'banner_updated_successfully' => 'Banner updated successfully',
    'banner_deleted_successfully' => 'Banner deleted successfully',
    'title' => 'Title',
    'brief' => 'Brief',
    'applies_to' => 'Applies to',
    'sort_order' => 'Sort order',
    'image' => 'Image',
    'products' => 'Products',
    'services' => 'Services',
];
