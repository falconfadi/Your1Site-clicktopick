<?php

return [
    'category_created_successfully' => 'Category created successfully',
    'category_updated_successfully' => 'Category updated successfully',
    'category_deleted_successfully' => 'Category deleted successfully',
    'name' => 'Name',
    'status' => 'Status',
    'is_active' => 'Status',
    'sort_order' => 'Sort order',
    'category_details' => 'Category details',
    'img' => 'Image',
    'guide_img' => 'Guide image',
    'info' => 'Information',
    'prod_sub_cat' => 'Products && SubCategories',
    'image' => 'Image',
    'images' => 'Images',
    'guide_image' => 'Guid Image',
    'view_tree'=> 'View Tree',
    'parent_category' => 'Parent Category',
    'View_categories_tree' => 'View Categories Tree',
    'close' => 'Close',
    'attributes' => 'Attributes',
    'type' => 'Type',
    'section' => 'Section'
];
