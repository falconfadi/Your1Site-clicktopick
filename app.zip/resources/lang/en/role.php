<?php

return [
    'name' => 'Name'
];
