<?php

return [
    'section_created_successfully' => 'Section created successfully',
    'section_updated_successfully' => 'Section updated successfully',
    'section_deleted_successfully' => 'Section deleted successfully',
    'name' => 'Name',
    'status' => 'Status',
    'is_active' => 'Status',
    'sort_order' => 'Sort order',
    'img' => 'Image',
    'image' => 'Image',
    'close' => 'Close',
    'slug' => 'Slug'
];
