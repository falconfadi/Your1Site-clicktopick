<?php

return [
    'slider_created_successfully' => 'تم انشاء السلايدر بنجاح',
    'slider_updated_successfully' => 'تم تعديل السلايدر بنجاح',
    'slider_deleted_successfully' => 'تم حذف السلايدر بنجاح',
    'sort_order' => 'الترتيب',
    'heading' => 'الترويسة',
    'title' => 'العنوان ',
    'brief' => 'الشرح',
    'main_heading' => 'الترويسة الرئيسية',
    'offer_percentage' => 'مقدار العرض',
    'offer_vertical' => 'Offer Vertical',
    'offer_duration' => 'مدة العرض',
    'background_image' => 'صور الخلفية',
    'responsive_image' => 'الصورة المتحركة',
    'product_id' => 'المنتج',
];
