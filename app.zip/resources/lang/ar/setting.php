<?php

return [
    'settings' => 'الإعادات',
    'key' => 'المفتاح',
    'type' => 'النمط',
    'select_type' => 'اختر النمط',
    'text' => 'نص',
    'textarea' => 'نص طويل',
    'text_area' => 'نص طويل',
    'text_editor' => 'محرر النصوص',
    'rich_text_box' => 'محرر النصوص',
    'number' => 'رقم',
    'image' => 'صورة',
    'album' => 'البوم صور',
    'checkbox' => 'اختيارات',
    'select' => 'اختيارات',
];
