<?php

return [
    'banner_created_successfully' => 'تم اضافة بانر جديدة بنجاح',
    'banner_updated_successfully' => 'تم تعديل بانر جديدة بنجاح',
    'banner_deleted_successfully' => 'تم حذف بانر جديدة بنجاح',
    'title' => 'عنوان',
    'brief' => 'ملخص',
    'applies_to' => 'تطبق على',
    'sort_order' => 'الترتيب',
    'image' => 'الصورة',
    'products' => 'المنتج',
    'services' => 'الخدمة',
];
