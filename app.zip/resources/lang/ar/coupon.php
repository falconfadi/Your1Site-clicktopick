<?php
return [
    'coupon_created_successfully' => 'تم انشاء الكوبون بنجاح',
    'coupon_updated_successfully' => 'تم تعديل الكوبون بنجاح',
    'coupon_deleted_successfully' => 'تم حذف الكوبون بنجاح',
    'sort_order' => 'الترتيب',
    'code' => 'الكود',
    'name' => 'الاسم',
    'coupon_value' => 'قيمة الخصم',
    'start_date' => 'تاريخ البدء',
    'end_date' => 'تاريخ الانتهاء',
    'min_amount' => 'اقل قيمة',
    'max_amount' => 'اعلي قيمة',
];
