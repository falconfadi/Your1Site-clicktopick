<?php

return [
    'name' => 'الاسم'
];
