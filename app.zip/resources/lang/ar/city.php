<?php

return [
    'city_created_successfully' => 'تم انشاء المدينة بنجاح',
    'city_updated_successfully' => 'تم تعديل المدينة بنجاح',
    'city_deleted_successfully' => 'تم حذف المدينة بنجاح',
    'name' => 'الاسم',
    'sort_order' => 'الترتيب',
    'country_id' => 'البلد',
    'country' => 'البلد',
];
