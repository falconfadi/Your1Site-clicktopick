<?php

return [
    'attribute_created_successfully' => 'تم انشاء الخاصية بنجاح',
    'attribute_updated_successfully' => 'تم تعديل الخاصية بنجاح',
    'attribute_deleted_successfully' => 'تم حذف الخاصية بنجاح',
    'name' => 'الاسم',
    'attribute_details' => 'التفاصيل',
    'img' => 'الصورة',
    'info' => 'المعلومات',
    'image' => 'صورة',
    'images' => 'الصور',
    'close' => 'اغلاق',
    'type' => 'النمط',
    'use_as_filter' => 'هل تريد استخدامها كـ فلتر ؟',
];
