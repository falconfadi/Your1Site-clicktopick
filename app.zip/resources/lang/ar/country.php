<?php

return [
    'country_created_successfully' => 'تم إضافة البلد بنجاح',
    'country_updated_successfully' => 'تم تحديث البلد بنجاح',
    'country_deleted_successfully' => 'تم حذف البلد بنجاح',
    'name' => 'الاسم',
    'flag' => 'العلم',
    'sort_order' => 'امر ترتيب',
];
